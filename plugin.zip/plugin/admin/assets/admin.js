jQuery(document).ready(function($) {
    // Admin JavaScript functionality
    console.log('OneFunders Analytics Admin loaded');
});


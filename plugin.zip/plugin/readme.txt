=== OneFunders Analytics ===
Contributors: OneFunders
Tags: analytics, trading, mt5
Requires at least: 6.0
Tested up to: 6.4
Stable tag: 1.0.0
Requires PHP: 8.1
License: GPLv2 or later

WordPress plugin for OneFunders Analytics dashboard and account management.

== Description ==

OneFunders Analytics provides a comprehensive analytics dashboard for MT5 trading accounts with real-time drawdown monitoring.

== Installation ==

1. Upload the plugin to `/wp-content/plugins/onefunders-analytics/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the backend API URL in Settings > OneFunders > Settings

== Changelog ==

= 1.0.0 =
* Initial release

